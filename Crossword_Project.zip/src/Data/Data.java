package Data;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Data {

    //array listst to hold data from the file
    private ArrayList<String> clues;
    private String[][] board;
    private final String SOLUTION;

    //constructor method to initialise the list and call method
    public Data(String filename, String solution) {
        clues = new ArrayList<>();
        this.SOLUTION = solution;
        loadData(filename); //call method to load data from the file
    }

    //method to load data from the input file
    public void loadData(String filename) {
        try {
            //open file in read mode
            Scanner in = new Scanner(new File(filename));
            String line = in.nextLine();

            //get the board size from first lines
            int rows = Integer.parseInt(line.split(" ")[0]);
            int cols = Integer.parseInt(line.split(" ")[1]);
            board = new String[rows][cols];
            int count = 0;
            //read line in a loop one by one
            while (in.hasNextLine()) {
                //read the whole board in separate loop
                while (count < rows && in.hasNextLine()) {
                    line = in.nextLine();
                    String[] s = line.split(" ");   //split each line by space
                    for (int a = 0; a < s.length; a++) {
                        board[count][a] = s[a]; //add each character to the board 2D array
                    }
                    count++;
                }
                line = in.nextLine();   //read all other lines 
                clues.add(line);    //add them to clues/instructions list

            }
        } catch (Exception ex) {
            //print here, if any error occures
            System.out.println("Error: " + ex.getMessage());
            System.exit(0);
        }
    }

    //method to get the list of clues
    public ArrayList<String> getClues() {
        return clues;
    }

    //method to return the 2D board array
    public String[][] getBoard() {
        return board;
    }

    //method to get the solution of the grey sqaures
    public String getSolution() {
        return SOLUTION;
    }

}
