package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

public class View implements ActionListener {

    //clas fields to store board, clues and buttons
    private String[][] board;
    private ArrayList<String> clues;
    private int greyCount;
    //grey buttons array at the bottom of screen
    private JButton[] greyButtons;
    private final String SOLUTION;

    //cosntructor method to set values for class fields
    public View(String[][] board, ArrayList<String> clues, String solution) {
        this.board = board;
        this.clues = clues;
        greyCount = 0;
        this.SOLUTION = solution;
    }

    //buttons 2D array
    private JButton[][] buttons;

    //method to setup and display the GUI
    public void setup() {
        //create a frame
        JFrame frame = new JFrame();
        frame.setLayout(null);

        //call method to get the main panel
        JPanel panel = mainPanel();
        //call method ot get the grey bottom panel
        JPanel greyPanel = greyPanel();

        //text area to dispaly the clues/instructions
        JTextPane area = new JTextPane();
        String str = "Crossword Puzzle Instructions: \n";
        area.setBounds(0, 0, 250, 700);
        area.setEditable(false);

        //add all the clues to the str
        for (int a = 0; a < clues.size(); a++) {
            str += clues.get(a) + "\n";
        }
        //add str to the text area
        area.setText(str);

        //set the frame size and add panels to it
        frame.add(area);
        frame.add(panel);
        frame.add(greyPanel);
        frame.setSize(900, 700);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true); //display the frame to the user
    }

    //fiuelds to store row and column number of the clicked button on the board
    int row = -1;
    int col = -1;
    JFrame kbFrame; //keyboard frame
    //method to handle the button clicks for all the buttons

    @Override
    public void actionPerformed(ActionEvent e) {
        //if the check button is clicked
        if (e.getActionCommand().equals("Check")) {
            String result = "";
            //get text from all the grey buttons to match with the solution
            for (int a = 0; a < greyButtons.length; a++) {
                result += greyButtons[a].getText(); //get all characters from all buttons
            }
            //match the result with the solution
            if (result.equalsIgnoreCase(SOLUTION)) {
                //if matched, print the success message
                JOptionPane.showMessageDialog(null, "Brilliant! You've guessed it right!");
            } else {
                //if failed, print the error message
                JOptionPane.showMessageDialog(null, "Oh No! Better Luck Next Time!");
            }
        } //if the any of the grey buttons is clicked
        else if (e.getActionCommand().startsWith("G")) {
            //setup the keyboard frame
            kbFrame = new JFrame();
            kbFrame.add(keyboard(e.getActionCommand()));    //call method to setup the keyboard
            kbFrame.setTitle("Enter a character");
            kbFrame.setSize(850, 150);
            kbFrame.setLocationRelativeTo(null);
            kbFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            kbFrame.setVisible(true);   //display the keyboard to select a character
        } else {  //other this block will be executed
            //get the row and col (location) of the clicked button from the board
            row = Integer.parseInt(e.getActionCommand().split(",")[0]);
            col = Integer.parseInt(e.getActionCommand().split(",")[1]);
            kbFrame = new JFrame();

            if (board[row][col].startsWith("X")) {  //black button
                //if the button is black square, ignore it
            } else {
                if (board[row][col].startsWith("H")) {   //blue button
                    //get the correct letter from the board array
                    String guess = board[row][col].substring(2, 3);
                    kbFrame.add(keyboard("H," + guess));    //call keyboard method with the guess
                } else if (board[row][col].startsWith("S")) { //grey button
                    kbFrame.add(keyboard("S")); //call keyboard method 
                } else {
                    kbFrame.add(keyboard("default"));
                }
                //display the setup keyboard
                kbFrame.setTitle("Enter a character");
                kbFrame.setSize(850, 150);
                kbFrame.setLocationRelativeTo(null);
                kbFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                kbFrame.setVisible(true);
            }
        }
    }

    private String selected = "";
    private JButton[] kbButtons;    //keyboard buttons

    //method to setup the keyboard panel
    public JPanel keyboard(String type) {
        //create a panel
        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());

        //create 26 buttons (A-Z)
        kbButtons = new JButton[26];
        kbButtons[0] = new JButton("A");
        kbButtons[1] = new JButton("Z");
        kbButtons[2] = new JButton("E");
        kbButtons[3] = new JButton("R");
        kbButtons[4] = new JButton("T");
        kbButtons[5] = new JButton("Y");
        kbButtons[6] = new JButton("U");
        kbButtons[7] = new JButton("I");
        kbButtons[8] = new JButton("O");
        kbButtons[9] = new JButton("P");
        kbButtons[10] = new JButton("Q");
        kbButtons[11] = new JButton("S");
        kbButtons[12] = new JButton("D");
        kbButtons[13] = new JButton("F");
        kbButtons[14] = new JButton("G");
        kbButtons[15] = new JButton("H");
        kbButtons[16] = new JButton("J");
        kbButtons[17] = new JButton("K");
        kbButtons[18] = new JButton("L");
        kbButtons[19] = new JButton("M");
        kbButtons[20] = new JButton("W");
        kbButtons[21] = new JButton("X");
        kbButtons[22] = new JButton("C");
        kbButtons[23] = new JButton("V");
        kbButtons[24] = new JButton("B");
        kbButtons[25] = new JButton("N");

        //action listener for all buttons
        ActionListener listener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selected = e.getActionCommand();
                if (type.startsWith("G")) {   //if its a grey button clicked earlier
                    //get the button number
                    int index = Integer.parseInt(type.substring(1, type.length()));
                    //add the selected character from the keyboard to the grey button (bottom)
                    greyButtons[index].setText(selected);
                } else {
                    //if blue button is clicked earlier
                    if (board[row][col].startsWith("H")) {
                        //add the selected character from the keyboard to the grey button (bottom)
                        buttons[row][col].setText(selected);
                    } //if special grey button is clicked earlier
                    else if (board[row][col].startsWith("S")) {
                        //add the selected character from the keyboard to the grey button (bottom)
                        buttons[row][col].setText(selected);
                    } else {  //else case for white squares
                        //add the selected character from the keyboard to the grey button (bottom)
                        buttons[row][col].setText(selected);
                    }
                }
                kbFrame.dispose();  //dispose the keyboard after character is selected
            }
        };
        //if the grey button is clicked earlier
        if (type.startsWith("G")) {
            //create all the keyboard buttons
            for (int a = 0; a < kbButtons.length; a++) {
                kbButtons[a].addActionListener(listener);
                p.add(kbButtons[a]);    //add all buttons to panel
            }
        } //if blue buttons is cliced 
        else if (type.startsWith("H")) {
            //disable all the buttons of keyboard (initially)
            for (int a = 0; a < kbButtons.length; a++) {
                kbButtons[a].addActionListener(listener);
                kbButtons[a].setEnabled(false);
                p.add(kbButtons[a]);//add all buttons to panel
            }
            //get the correct character
            String guess = type.substring(2, 3);
            for (int a = 0; a < kbButtons.length; a++) {
                if (kbButtons[a].getText().equals(guess)) {
                    kbButtons[a].setEnabled(true);  //find the button and enable the correct letter button
                    break;
                }
            }
            int actives = 0;
            //while loop to randomly activate 4 more buttons
            while (actives < 4) {
                //create a ranom number
                int rand = (int) ((Math.random() * (26 - 0)) + 0);
                if (kbButtons[rand] != null && !kbButtons[rand].isEnabled()) {
                    kbButtons[rand].setEnabled(true);   //enable 4 buttons that are not already enabled
                    actives++;
                }
            }
        } else { //block for white buttons
            for (int a = 0; a < kbButtons.length; a++) {
                kbButtons[a].addActionListener(listener);
                p.add(kbButtons[a]);//add all buttons to panel
            }
        }
        return p;
    }

    //method to create the panel for grey buttons
    private JPanel greyPanel() {
        //create panel
        JPanel greyPanel = new JPanel();
        greyPanel.setLayout(null);
        greyPanel.setBounds(260, 600, 630, 50);
        //create array of buttons
        greyButtons = new JButton[greyCount];
        int x = 0;
        //create all buttons and add them to the bottom grey panel
        for (int a = 0; a < greyCount; a++) {
            greyButtons[a] = new JButton("", new ImageIcon("icons/grey.png"));
            greyButtons[a].setHorizontalTextPosition(SwingConstants.CENTER);
            greyButtons[a].setBounds(x, 0, 50, 50);
            greyButtons[a].setActionCommand("G" + a);
            greyButtons[a].addActionListener(this);
            greyPanel.add(greyButtons[a]);
            x += 52;
        }
        //create and add a check button the panel
        JButton check = new JButton("Check");
        check.addActionListener(this);
        check.setBounds(x, 10, 70, 30);
        greyPanel.add(check);
        return greyPanel;   //return the panel
    }

    //method to set the main panel (board panel)
    private JPanel mainPanel() {
        //create panel and set its dimensions and location on the frame
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(board.length, board[0].length));
        panel.setBounds(260, 0, 630, 590);

        //create the buttons 2D arraynfr baord
        buttons = new JButton[board.length][board[0].length];
        //crete all the buttons
        for (int a = 0; a < buttons.length; a++) {
            for (int b = 0; b < buttons[a].length; b++) {
                buttons[a][b] = new JButton();
                //if the H character is found in the board string array
                if (board[a][b].startsWith("H")) {
                    //create and set a blue button
                    buttons[a][b] = new JButton("", new ImageIcon("icons/blue.png"));
                    buttons[a][b].setHorizontalTextPosition(SwingConstants.CENTER);
                }
                //if the X character is found in the board string array
                if (board[a][b].startsWith("X")) {
                    //create and set a black button
                    buttons[a][b] = new JButton(new ImageIcon("icons/black.png"));
                }
                //if the S character is found in the board string array
                if (board[a][b].startsWith("S")) {
                    //create and set a greybutton
                    buttons[a][b] = new JButton(new ImageIcon("icons/grey.png"));
                    buttons[a][b].setHorizontalTextPosition(SwingConstants.CENTER);
                    greyCount++;
                }
                //set action command for all buttons (button's location is ssetting as action command)
                //so that we can determine later, that which button is clicked
                buttons[a][b].setActionCommand(a + "," + b);
                buttons[a][b].addActionListener(this);
                panel.add(buttons[a][b]);   //add all buttons to the panel
            }
        }
        return panel;   //return the main panel
    }
}
