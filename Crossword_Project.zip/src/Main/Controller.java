package Main;

import Data.Data;
import GUI.View;
import java.util.*;

public class Controller {

    public static String[][] board;
    public static ArrayList<String> clues;

    public static void main(String[] args) {
        //FOR TESTING ONLY (BELOW 2 LINES)
        //String filename = "Puzzle-1.txt";
        //String solution = "southpark";
        
        //get the input vlaues from the arguments
        if(args.length != 2){
            System.exit(0);
        }
        String filename = args[0];
        String solution = args[1];
        

        //create Data class instance
        Data data = new Data(filename, solution);
        //call method to setup board and clues
        board = data.getBoard();
        clues = data.getClues();

        //create View class instance with values
        View v = new View(board, clues, solution);
        v.setup();  //call method to display the GUI

    }

}
