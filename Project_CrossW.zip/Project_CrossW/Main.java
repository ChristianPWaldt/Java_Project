import gui.GameFrame;
import logic.io.PuzzleParser;

/**
 * Main class with the entry point to the program.
 */
public class Main {

    /**
     * Main method. The arguments must contain the puzzle file path as first
     * argument and the solution as the second argument. Otherwise the program will
     * display an error message to the console and exit immediatly.
     * 
     * @param args the comamnd line arguments
     */
    public static void main(String[] args) {
        // check if two arguments are provided
        if (args.length != 2) {
            System.err.println("The game needs to be provided with a puzzle file as first argument and the solution as the second argument!");
            return;
        }

        // create a puzzle parser to parse the input file from the first argument
        PuzzleParser parser = new PuzzleParser(args[0]);
        String solution = args[1];

        // create the game frame using the results from the parser
        new GameFrame(parser.getBoard(), parser.getInstructions(), solution);
    }

}
