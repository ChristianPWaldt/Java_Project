package gui;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JPanel;

import logic.square.Square;

/**
 * The crossword panel holds the squares where you enter the letters using the
 * hints from the instruction panel.
 */
public class CrosswordPanel extends JPanel {

    /**
     * Creates the crossword panel using the square layout.
     * 
     * @param squares the board
     */
    public CrosswordPanel(Square[][] squares) {
        // setup the panel
        int rows = squares.length;
        int columns = squares[0].length;
        this.setPreferredSize(new Dimension(800, 800));
        this.setLayout(new GridLayout(rows, columns));

        // add the squares to the panel
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < columns; j++)
                this.add(squares[i][j]);
    }

}
