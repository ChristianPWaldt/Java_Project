package gui;

import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * The instruction panel lists the clues and instructions.
 */
public class InstructionPanel extends JPanel {

    /**
     * Creates the instruction panel with the given instruction string.
     * 
     * @param instructions the instructions
     */
    public InstructionPanel(String instructions) {
        // display the instructions in a text area
        JTextArea area = new JTextArea(instructions);
        area.setEditable(false);
        this.add(area);
    }

}
