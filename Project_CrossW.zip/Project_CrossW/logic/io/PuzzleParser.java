package logic.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import logic.square.BlackSquare;
import logic.square.HelpSquare;
import logic.square.SpecialSquare;
import logic.square.Square;
import logic.square.WhiteSquare;

/**
 * Class to parse the content of a puzzle file.
 */
public class PuzzleParser {

    /**
     * The file object that get's parsed.
     */
    private final File file;

    /**
     * The board consisting out of square objects.
     */
    private Square[][] board;
    /**
     * The instructions string build from the puzzle file.
     */
    private String instructions;

    /**
     * Creates a new puzzle parser that tries to parse the file under the given
     * path.
     * 
     * @param puzzleFile the path to the puzzle file
     */
    public PuzzleParser(String puzzleFile) {
        this.file = new File(puzzleFile);

        // parse the file
        this.parse();
    }

    /**
     * Parses the file given initially to this file parser. If an error occurred
     * during parsing, this method will return false. If the parsing was successful,
     * true is returned.
     * 
     * @return if the parsing was successful
     */
    private boolean parse() {
        // create a buffered reader to read line by line from the file
        try (BufferedReader reader = new BufferedReader(new FileReader(this.file))) {
            // the first line has to exist in order to set the bounds of the board
            String line = reader.readLine();
            if (line == null)
                return false;

            // extract the dimensions from the first line
            // the rows and columns are seperated by a single space character
            // addidtionally, both have to be greater than zero in order to create a valid
            // board
            String[] dimensions = line.split(" ");
            int rows = Integer.parseInt(dimensions[0]);
            if (rows <= 0)
                return false;

            int columns = Integer.parseInt(dimensions[1]);
            if (columns <= 0)
                return false;

            // create the board using the parsed dimensions
            this.board = new Square[rows][columns];
            // iterate over the next rows in order to read the whole board
            for (int i = 0; i < rows; i++) {
                // the current row
                line = reader.readLine();
                if (line == null)
                    return false;

                // split the row by space characters to extract the individual fields
                // each row has to have a length of columns
                String[] squares = line.split(" ");
                if (squares.length != columns)
                    return false;

                for (int j = 0; j < columns; j++) {
                    // parse the square from the given string
                    Square square = this.parseSquare(squares[j]);
                    if (square == null)
                        return false;

                    // add the square to the board
                    this.board[i][j] = square;
                }
            }

            // concatenate the remaining lines and build the instructions from those
            StringBuilder builder = new StringBuilder("Crossword puzzle instructions:\n");
            while ((line = reader.readLine()) != null)
                builder.append('\n').append(line);
            this.instructions = builder.toString();

            // parsing was successful
            return true;
        } catch (Exception e) {
            // catch any exceptions, print the error message and return properly
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Parses a square from the given string.
     * 
     * @param string the string
     * @return the parsed square or null when failed
     */
    private Square parseSquare(String string) {
        // the first character in the string determinates the type of the square
        switch (string.charAt(0)) {
        case 'O':
            return new WhiteSquare();
        case 'X':
            return new BlackSquare();
        case 'S':
            return new SpecialSquare();
        case 'H':
            // the help square additionally requires the actual value
            return new HelpSquare(string.charAt(2));
        }
        return null;
    }

    /**
     * Returns the parsed board.
     * 
     * @return the board
     */
    public Square[][] getBoard() {
        return this.board;
    }

    /**
     * Returns the parsed instructions.
     * 
     * @return the instructions
     */
    public String getInstructions() {
        return this.instructions;
    }

}
