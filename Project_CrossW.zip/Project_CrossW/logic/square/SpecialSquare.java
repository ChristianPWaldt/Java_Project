package logic.square;

import java.awt.Color;

/**
 * A special square holds one of the letters that are part of the solution.
 */
public class SpecialSquare extends EditableSquare {

    @Override
    public Color getColor() {
        return Color.GRAY;
    }

}
