package logic.square;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;

/**
 * The abstract square class to represent an individual square.
 *
 * A square is a special button with a pre-determinated color.
 */
public abstract class Square extends JButton {

    /**
     * Sets the basic square up.
     */
    public Square() {
        // set the color and size of this square
        this.setBackground(this.getColor());
        this.setPreferredSize(new Dimension(50, 50));
    }

    /**
     * Returns the color of this square.
     * 
     * @return the color
     */
    public abstract Color getColor();

}
