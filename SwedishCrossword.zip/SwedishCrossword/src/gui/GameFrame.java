package gui;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JFrame;

import logic.io.Clue;
import logic.square.Square;

/**
 * The game frame is the main window. It holds the instruction panel, the actual
 * crossword panel and the solution panel.
 */
public class GameFrame extends JFrame {

    /**
     * Creates a new game frame.
     * 
     * @param board        the board layout of squares
     * @param instructions the instructions
     * @param solution     the solution of the puzzle
     */
    public GameFrame(Square[][] board, List<List<Clue>> instructions, String solution) {
        // setup the frame
        super("Swedish-style crossword puzzle");
        this.setSize(1000, 1000);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(new BorderLayout());

        // add the components to the frame
        this.add(new InstructionPanel(instructions), BorderLayout.WEST);
        this.add(new CrosswordPanel(board), BorderLayout.CENTER);
        this.add(new SolutionPanel(solution), BorderLayout.SOUTH);

        // show the window
        this.setVisible(true);
    }

}
