package gui;

import java.awt.Color;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import logic.io.Clue;

/**
 * The instruction panel lists the clues and instructions.
 */
public class InstructionPanel extends JPanel {

    /**
     * The color used in the text pane.
     */
    public static final Color PURPLE = new Color(96, 0, 192);

    /**
     * Creates the instruction panel with the given instructions.
     * 
     * @param instructions the instructions
     */
    public InstructionPanel(List<List<Clue>> instructions) {
        // create a text pane to display the instructions with styles
        JTextPane area = new JTextPane();
        area.setEditable(false);
        StyledDocument document = area.getStyledDocument();

        // create a normal and a title style
        Style normal = area.addStyle("normal", null);
        StyleConstants.setBold(normal, true);

        // the title style has another color than the normal style
        Style title = area.addStyle("title", normal);
        StyleConstants.setForeground(title, PURPLE);

        // insert all the clues into the document
        try {
            // insert the title of the text pane
            document.insertString(document.getLength(), "Crossword puzzle instructions:\n\n", title);
            
            for (List<Clue> clues : instructions) {
                // insert the title of the current section (ACROSS or DOWN)
                document.insertString(document.getLength(), clues.get(0).instruction + "\n", title);
                for (int i = 1; i < clues.size(); i++) {
                    // insert the clues for each section
                    Clue clue = clues.get(i);
                    document.insertString(document.getLength(), clue.line + ". ", title);
                    document.insertString(document.getLength(), clue.instruction + "\n", normal);
                }
            }
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
        this.add(area);
    }

}
