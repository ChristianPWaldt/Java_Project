package gui;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

import logic.square.EditableSquare;

/**
 * The keyboard is a helping frame to enter the letters for the puzzle.
 */
public class Keyboard extends JFrame {

    /**
     * All allowed keys in the right order.
     */
    public static final char[] KEYS = "AZERTYUIOPQSDFGHJKLMWXCVBN".toCharArray();

    /**
     * The square that get's currently edited.
     */
    private final EditableSquare square;

    /**
     * Opens the keyboard for the given square
     * 
     * @param square
     */
    public Keyboard(EditableSquare square) {
        // setup the basic frame
        super("Enter a character");
        this.square = square;

        this.setSize(1000, 200);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);

        // add the keys
        this.setLayout(new FlowLayout());
        for (char c : KEYS)
            this.add(this.createKey(c));

        // show the keyboard
        this.setVisible(true);
    }

    /**
     * Creates the key for the given letter.
     * 
     * @param c the letter
     * @return the created key
     */
    private JButton createKey(char c) {
        // create the button for the key
        JButton key = new JButton(String.valueOf(c));
        key.addActionListener(e -> Keyboard.this.charTyped(c));
        key.setPreferredSize(new Dimension(85, 25));
        // set the key enabled if the square can accept the given letter
        key.setEnabled(this.square.isValidKey(c));
        return key;
    }

    /**
     * Get's executed when a button is pressed. This method will then set the text
     * of the editing square to the typed char and close the keyboard frame.
     * 
     * @param c the letter that got pressed
     */
    private void charTyped(char c) {
        this.square.setText(String.valueOf(c));
        this.dispose();
    }

}
