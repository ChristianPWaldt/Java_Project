package gui;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * Shows a small window that tells the player whether his entered solution is
 * correct or incorrect.
 * 
 * @param correct whether the solution is correct or not
 */

/**
 * This class opens a small window that tells the player whether his entered
 * solution is correct or incorrect.
 */
public class SolutionFrame extends JFrame {

    /**
     * Constructs a new SolutionFrame with the given boolean indicating whether the
     * entered solution is correct or not.
     * 
     * @param correct whether the entered solution is correct
     */
    public SolutionFrame(boolean correct) {
        // sets up the basic properties of the frame
        super(correct ? "You won!" : "Incorrect.");
        this.setSize(300, 100);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(new FlowLayout());

        // adds a label to display the message and a button to close the window
        this.add(new JLabel(correct ? "Congratulations! You found the solution." : "Sorry! This is not the correct answer."));
        JButton button = new JButton("Close");
        button.setPreferredSize(new Dimension(75, 25));
        button.addActionListener(e -> this.dispose());
        this.add(button);

        // shows the window
        this.setVisible(true);
    }

}
