package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

import logic.square.SpecialSquare;

/**
 * The solution panel contains the special squares that form the solution aswell
 * as a button to check if the solution is actually correct.
 */
public class SolutionPanel extends JPanel {

    /**
     * The color of the special squares if the solution is correct.
     */
    public static final Color GREEN = new Color(10, 240, 80);

    /**
     * The solution of the puzzle.
     */
    private final String solution;
    /**
     * The row of special squares that forms the solution.
     */
    private final SpecialSquare[] row;

    /**
     * Creates the solution panel.
     * 
     * @param solution the solution to the puzzle
     */
    public SolutionPanel(String solution) {
        this.solution = solution;
        int length = solution.length();

        // create the solution row panel
        JPanel solutionRow = new JPanel();
        solutionRow.setLayout(new GridLayout(1, length, 3, 3));
        solutionRow.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
        solutionRow.setBackground(Color.BLACK);
        // create the special squares and add them to the solution row panel
        this.row = new SpecialSquare[length];
        for (int i = 0; i < length; i++) {
            this.row[i] = new SpecialSquare();
            solutionRow.add(this.row[i]);
        }
        // add the solution row panel to this solution panel
        this.add(solutionRow);

        // create and add the check button
        JButton check = new JButton("check");
        check.setPreferredSize(new Dimension(75, 25));
        // check the solution and open the solution frame
        check.addActionListener(e -> new SolutionFrame(this.check()));
        this.add(check);
    }

    /**
     * Checks if the special squares contains the correct letters. If so, their
     * color will be set to green to display that the puzzle is finished.
     * 
     * @return if the solution is correct
     */
    private boolean check() {
        // iterate over each special square
        for (int i = 0; i < this.row.length; i++) {
            // request the content of the special square and check if it contains exactly
            // one char
            String text = this.row[i].getText();
            if (text.length() != 1)
                return false;

            // check if ith square contains the same letter as the solution string at the
            // ith position
            if (Character.toLowerCase(text.charAt(0)) != this.solution.charAt(i))
                return false;
        }

        return true;
    }

}
