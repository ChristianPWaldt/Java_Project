package logic.io;

/**
 * A simple dataclass to store the row / column and the instruction of a single
 * clue.
 */
public class Clue {

    /**
     * The row / column of the clue.
     */
    public int line;
    /**
     * The instruction string.
     */
    public String instruction;

    /**
     * Creates a new clue with the given information.
     * 
     * @param line        the row / column
     * @param instruction the string
     */
    public Clue(int line, String instruction) {
        this.line = line;
        this.instruction = instruction;
    }

}
