package logic.square;

import java.awt.Color;

/**
 * A black square is the basic square that cannot hold a letter and signlas the
 * end of a word or phrase.
 */
public class BlackSquare extends Square {

    /**
     * Constructs a new black square.
     */
    public BlackSquare() {
        // black do not hold values and thus need no action
        this.setEnabled(false);
    }

    @Override
    public Color getColor() {
        return Color.BLACK;
    }

}
