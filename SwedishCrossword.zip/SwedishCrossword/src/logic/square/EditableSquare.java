package logic.square;

import gui.Keyboard;

/**
 * An editable square can hold a single character.
 */
public abstract class EditableSquare extends Square {

    /**
     * Sets up the editable square.
     */
    public EditableSquare() {
        // the square opens the keyboard when clicked to set it's own value
        this.addActionListener(e -> new Keyboard(this));
    }

    /**
     * Checks if the given letter can be typed in this square.
     * 
     * @param c the letter
     * @return if the letter can be typed
     */
    public boolean isValidKey(char c) {
        return true;
    }

}
