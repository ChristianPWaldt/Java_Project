package logic.square;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import gui.Keyboard;

/**
 * A help square can hold only a specific amount of different characters, one of
 * them beeing the correct one.
 */
public class HelpSquare extends EditableSquare {

    /**
     * The color of the help square.
     */
    public static final Color LIGHT_BLUE = new Color(60, 210, 240);
    /**
     * The amount of different characters this square can hold.
     */
    public static final int OPTIONS = 5;

    /**
     * The different characters this square can hold.
     */
    private final char[] options = new char[OPTIONS];

    /**
     * Creates a new help square. The given value is the correct value of this
     * square.
     * 
     * @param value the correct letter
     */
    public HelpSquare(char value) {
        // assign the correct letter as first option
        this.options[0] = value;

        // generate the other options ranomly
        this.generateRandomOptions();
    }

    private void generateRandomOptions() {
        // create a list and store all characters, except for the correct one in it
        List<Character> chars = new ArrayList<>();
        for (char c : Keyboard.KEYS)
            if (c != this.options[0])
                chars.add(c);

        // remove characters randomly from the list and store them as options, until all
        // options are filled
        Random r = new Random();
        for (int i = 1; i < this.options.length; i++)
            this.options[i] = chars.remove(r.nextInt(chars.size()));
    }

    @Override
    public Color getColor() {
        return LIGHT_BLUE;
    }

    @Override
    public boolean isValidKey(char c) {
        // check if the options contains the specific key
        for (int i = 0; i < this.options.length; i++)
            if (this.options[i] == c)
                return true;

        return false;
    }

}
