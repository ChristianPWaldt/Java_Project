package logic.square;

import java.awt.Color;

/**
 * A white square is the basic square that can hold a letter.
 */
public class WhiteSquare extends EditableSquare {

    @Override
    public Color getColor() {
        return Color.WHITE;
    }

}
